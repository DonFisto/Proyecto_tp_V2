var camara_8h =
[
    [ "Camara", "camara_8h.html#a5a090cb3901792e2c69a5e80db447fc5", null ],
    [ "camera_follow", "camara_8h.html#ac3c737b597742246198e4dba36ccf9b7", null ],
    [ "create_camera", "camara_8h.html#a00f4005750eb590909c1831178f1fc5a", null ],
    [ "free_cam", "camara_8h.html#a81b7be31934f35901f79902877cd5195", null ],
    [ "get_cam_x", "camara_8h.html#a1c8d7528ae62ca0169a98d3705884beb", null ],
    [ "get_cam_y", "camara_8h.html#a3c5898da4da276b7d3a76d2cac3e7101", null ]
];