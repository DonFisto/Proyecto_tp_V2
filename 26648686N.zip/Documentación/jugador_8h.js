var jugador_8h =
[
    [ "Jugador", "jugador_8h.html#a4789fa433872c7245588938a8470968e", null ],
    [ "color_change", "jugador_8h.html#a5330ab355968c84a316e40e613641939", null ],
    [ "create_player", "jugador_8h.html#aa663c707c75b55b00f96087161236b61", null ],
    [ "dmg", "jugador_8h.html#afe1e1834c33976f73682894c2ec08c2a", null ],
    [ "draw_player", "jugador_8h.html#a1714ce39635063be438c53d6462b3481", null ],
    [ "free_player", "jugador_8h.html#ab7ebd1f84bb36b83419fed4bc7e74e04", null ],
    [ "get_player_aimx", "jugador_8h.html#a338f0ca6b0be979f590a16aba03f14cd", null ],
    [ "get_player_aimy", "jugador_8h.html#ac957819265fea0733a3945581068fb0b", null ],
    [ "get_player_cooldown", "jugador_8h.html#ac6aada50d7fd4f24d2a8af5173554dde", null ],
    [ "get_player_energy", "jugador_8h.html#a4bd4ea540166c171bf7ed50ac3822cdf", null ],
    [ "get_player_height", "jugador_8h.html#a5afdc8f66a11560b87b50426e9c07ab2", null ],
    [ "get_player_inv", "jugador_8h.html#ac000e4c4dca9b44d823285d7d278bf03", null ],
    [ "get_player_lives", "jugador_8h.html#a7e047d164f193e94b4e8d4091189d266", null ],
    [ "get_player_pos_x", "jugador_8h.html#ab247096c7653f4cd5d7cca55d4ad7ffc", null ],
    [ "get_player_pos_y", "jugador_8h.html#ac1224dc65c3220f538fde1da645c119a", null ],
    [ "get_player_width", "jugador_8h.html#ae8a0311a218acc34f72a189a44c8602b", null ],
    [ "move_player", "jugador_8h.html#a1eef3f7b5bedec2d09ec91ff8c664915", null ],
    [ "set_energy", "jugador_8h.html#ad0877c163e49fa945b0a2555b52b7d1d", null ],
    [ "set_inv", "jugador_8h.html#a47348051575734f5cfe5c1c942cb8509", null ],
    [ "set_lives", "jugador_8h.html#a12069f961308fd1f6ef02047f6f23cd4", null ],
    [ "set_triple_shot", "jugador_8h.html#a60eb399a4d342b77faa2b8dace18807a", null ]
];