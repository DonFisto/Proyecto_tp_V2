var rafaga_8h =
[
    [ "Rafaga", "rafaga_8h.html#a6519f018966f2cec586d967c900920dc", null ],
    [ "burst_shot_collision", "rafaga_8h.html#a18a18fbd3e890c37d9142d059a8198a2", null ],
    [ "burst_shot_lenght", "rafaga_8h.html#ae6c2a72b915e08e2890b65ed95c667c6", null ],
    [ "create_burst_shot", "rafaga_8h.html#aad22320bf078cb955f001ddba1f3f40d", null ],
    [ "draw_burst_shot", "rafaga_8h.html#aea7e2b63a81e797ce662dff802279ee4", null ],
    [ "free_burst_shot", "rafaga_8h.html#ab438410d7d17d4e27d00cf5486f467da", null ],
    [ "insert_burst", "rafaga_8h.html#a83bbc39efecd73cb24d71a7fbffa2203", null ],
    [ "move_burst_shot", "rafaga_8h.html#a612349753bed4ab5692ae876d3b1e212", null ]
];