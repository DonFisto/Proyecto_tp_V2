var consumibles_8h =
[
    [ "Caja", "consumibles_8h.html#ab705aa163215c987771f95a64e3ca342", null ],
    [ "box_collision", "consumibles_8h.html#ac0dea625e3467c75574b4165eda1fe6b", null ],
    [ "create_box", "consumibles_8h.html#a6390f5377c4058d4fc20512ae97238a0", null ],
    [ "draw_box", "consumibles_8h.html#ab7808469a9a0d81efeb8546ee07f8234", null ],
    [ "free_box", "consumibles_8h.html#aace2ba3783e09bea53480e51e428c071", null ],
    [ "get_box_type", "consumibles_8h.html#a98335e68a604a866c68a698ae63822e5", null ],
    [ "get_box_x", "consumibles_8h.html#a6bc55af92a3c19b8ced5491ef11cf5e3", null ],
    [ "get_box_y", "consumibles_8h.html#a4f6308290b6e1d68b3f4f4695522e860", null ],
    [ "move_box", "consumibles_8h.html#a16276f23ea5489572277d8aa5b6c3836", null ]
];