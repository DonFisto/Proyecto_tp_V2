var files_dup =
[
    [ "bala.h", "bala_8h.html", "bala_8h" ],
    [ "camara.h", "camara_8h.html", "camara_8h" ],
    [ "colisiones.h", "colisiones_8h.html", "colisiones_8h" ],
    [ "constantes.h", "constantes_8h.html", null ],
    [ "consumibles.h", "consumibles_8h.html", "consumibles_8h" ],
    [ "enemigos.h", "enemigos_8h.html", "enemigos_8h" ],
    [ "jugador.h", "jugador_8h.html", "jugador_8h" ],
    [ "mapa.h", "mapa_8h.html", "mapa_8h" ],
    [ "partida.h", "partida_8h.html", "partida_8h" ],
    [ "rafaga.h", "rafaga_8h.html", "rafaga_8h" ]
];