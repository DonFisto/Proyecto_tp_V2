var searchData=
[
  ['add_5fgame_5fpts_0',['add_game_pts',['../partida_8h.html#ac88aa86b5447eb7285002259e67dd3f6',1,'partida.h']]],
  ['army_5fbehavior_1',['army_behavior',['../partida_8h.html#a46afc68a3fcd82b42f7be1d443085f86',1,'partida.h']]],
  ['army_5fburst_5fshot_5fcollision_2',['army_burst_shot_collision',['../enemigos_8h.html#ae61339e3d64041995b7a94b123fd096d',1,'enemigos.h']]],
  ['army_5fgeneration_3',['army_generation',['../partida_8h.html#a5bfd83b455ad7f92d32f81defdb5b8d3',1,'partida.h']]],
  ['ayuda_4',['ayuda',['../partida_8h.html#a18204669321af13387fc2b6583e0a524',1,'partida.h']]]
];
