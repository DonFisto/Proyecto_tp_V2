var searchData=
[
  ['camera_5ffollow_0',['camera_follow',['../camara_8h.html#ac3c737b597742246198e4dba36ccf9b7',1,'camara.h']]],
  ['check_5fend_5fgame_1',['check_end_game',['../partida_8h.html#adef099354cca60bfd05c0a86e92372b7',1,'partida.h']]],
  ['color_5fchange_2',['color_change',['../jugador_8h.html#a5330ab355968c84a316e40e613641939',1,'jugador.h']]],
  ['create_5farmy_3',['create_army',['../enemigos_8h.html#aa1897a656e1c037fddbfe14d51a92ab4',1,'enemigos.h']]],
  ['create_5fbox_4',['create_box',['../consumibles_8h.html#a6390f5377c4058d4fc20512ae97238a0',1,'consumibles.h']]],
  ['create_5fbullet_5',['create_bullet',['../bala_8h.html#a244083c731d4e26573ea720d42a6290c',1,'bala.h']]],
  ['create_5fburst_5fshot_6',['create_burst_shot',['../rafaga_8h.html#aad22320bf078cb955f001ddba1f3f40d',1,'rafaga.h']]],
  ['create_5fcamera_7',['create_camera',['../camara_8h.html#a00f4005750eb590909c1831178f1fc5a',1,'camara.h']]],
  ['create_5fmap_8',['create_map',['../mapa_8h.html#a84c0f5e7b6e1906f9906f709e0a84664',1,'mapa.h']]],
  ['create_5fplayer_9',['create_player',['../jugador_8h.html#aa663c707c75b55b00f96087161236b61',1,'jugador.h']]]
];
