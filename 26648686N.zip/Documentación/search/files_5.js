var searchData=
[
  ['partida_2eh_0',['partida.h',['../partida_8h.html',1,'']]]
];
