var searchData=
[
  ['rafaga_0',['Rafaga',['../rafaga_8h.html#a6519f018966f2cec586d967c900920dc',1,'rafaga.h']]],
  ['rafaga_2eh_1',['rafaga.h',['../rafaga_8h.html',1,'']]],
  ['read_5fmap_2',['read_map',['../mapa_8h.html#a29afdbd09b66f4bc1313d60cae4fbbff',1,'mapa.h']]],
  ['read_5frecords_3',['read_records',['../partida_8h.html#a4dad12e5ad90b3f2812cd58a6def5a9c',1,'partida.h']]],
  ['reset_5fmap_4',['reset_map',['../mapa_8h.html#a7bf73bfb7d91ad589a56dab83a81b87d',1,'mapa.h']]]
];
