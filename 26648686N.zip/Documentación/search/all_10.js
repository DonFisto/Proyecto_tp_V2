var searchData=
[
  ['unpause_0',['unpause',['../partida_8h.html#aad7247efbebacfb008438157f266a70b',1,'partida.h']]],
  ['update_5frecords_1',['update_records',['../partida_8h.html#a6910b6d89d6e8c4cf8537e96ac40ef19',1,'partida.h']]]
];
