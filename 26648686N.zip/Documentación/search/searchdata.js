var indexSectionsWithContent =
{
  0: "abcdefgijlmoprsu",
  1: "bcejmpr",
  2: "abcdefgilmoprsu",
  3: "bcejmpr",
  4: "fs"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Archivos",
  2: "Funciones",
  3: "typedefs",
  4: "Páginas"
};

