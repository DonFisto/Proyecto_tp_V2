var searchData=
[
  ['rafaga_0',['Rafaga',['../rafaga_8h.html#a6519f018966f2cec586d967c900920dc',1,'rafaga.h']]]
];
