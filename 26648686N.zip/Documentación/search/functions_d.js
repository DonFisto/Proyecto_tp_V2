var searchData=
[
  ['save_5fmap_0',['save_map',['../mapa_8h.html#a699dd4d0b84850d7b319285c1c6be2ed',1,'mapa.h']]],
  ['set_5fealive_1',['set_ealive',['../enemigos_8h.html#a2de475bf7ef11c273a716d82279c0051',1,'enemigos.h']]],
  ['set_5fenergy_2',['set_energy',['../jugador_8h.html#ad0877c163e49fa945b0a2555b52b7d1d',1,'jugador.h']]],
  ['set_5finv_3',['set_inv',['../jugador_8h.html#a47348051575734f5cfe5c1c942cb8509',1,'jugador.h']]],
  ['set_5flives_4',['set_lives',['../jugador_8h.html#a12069f961308fd1f6ef02047f6f23cd4',1,'jugador.h']]],
  ['set_5ftriple_5fshot_5',['set_triple_shot',['../jugador_8h.html#a60eb399a4d342b77faa2b8dace18807a',1,'jugador.h']]],
  ['solape_5fcirc_5frect_6',['solape_circ_rect',['../colisiones_8h.html#a8bd7b0a7f217ea974e906755c7f63cdd',1,'colisiones.h']]],
  ['solape_5fcircunferencias_7',['solape_circunferencias',['../colisiones_8h.html#af0205cd3019b3d690c2777211d186f06',1,'colisiones.h']]],
  ['solape_5frecta_5frect_8',['solape_recta_rect',['../colisiones_8h.html#a5a08105be4b903b86860711b948abbae',1,'colisiones.h']]],
  ['solape_5frectangulos_9',['solape_rectangulos',['../colisiones_8h.html#a544b92914ea291ac6cb43bd255d584d7',1,'colisiones.h']]],
  ['start_5fgame_10',['start_game',['../partida_8h.html#a7e105c865ca054f563e5afb7a2b4a7dd',1,'partida.h']]]
];
