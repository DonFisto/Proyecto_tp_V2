var searchData=
[
  ['ejercitorep_0',['EjercitoRep',['../struct_ejercito_rep.html',1,'']]],
  ['enemigorep_1',['EnemigoRep',['../struct_enemigo_rep.html',1,'']]]
];
