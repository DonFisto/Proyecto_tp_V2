var searchData=
[
  ['insert_5fburst_0',['insert_burst',['../rafaga_8h.html#a83bbc39efecd73cb24d71a7fbffa2203',1,'rafaga.h']]],
  ['insert_5fenemy_1',['insert_enemy',['../enemigos_8h.html#a933f4ecbd3c2312307e26030328ad29a',1,'enemigos.h']]]
];
