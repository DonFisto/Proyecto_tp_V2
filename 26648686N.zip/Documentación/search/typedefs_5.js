var searchData=
[
  ['partida_0',['Partida',['../partida_8h.html#a70d88e691110f4f1ec62f3cd23c15bf6',1,'partida.h']]]
];
