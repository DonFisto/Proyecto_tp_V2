var searchData=
[
  ['partida_0',['Partida',['../partida_8h.html#a70d88e691110f4f1ec62f3cd23c15bf6',1,'partida.h']]],
  ['partida_2eh_1',['partida.h',['../partida_8h.html',1,'']]],
  ['pause_5fmenu_2',['pause_menu',['../partida_8h.html#a463b9236bf099a389ee681d2c2b1ccb0',1,'partida.h']]],
  ['print_5fmap_3',['print_map',['../mapa_8h.html#a4609365e208cf810edd0c3ef1b96c934',1,'mapa.h']]]
];
