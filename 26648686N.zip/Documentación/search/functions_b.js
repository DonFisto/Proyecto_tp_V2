var searchData=
[
  ['pause_5fmenu_0',['pause_menu',['../partida_8h.html#a463b9236bf099a389ee681d2c2b1ccb0',1,'partida.h']]],
  ['print_5fmap_1',['print_map',['../mapa_8h.html#a4609365e208cf810edd0c3ef1b96c934',1,'mapa.h']]]
];
