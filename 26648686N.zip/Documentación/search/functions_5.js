var searchData=
[
  ['free_5farmy_0',['free_army',['../enemigos_8h.html#af841101131751dfb868b8c7d067507c2',1,'enemigos.h']]],
  ['free_5fbox_1',['free_box',['../consumibles_8h.html#aace2ba3783e09bea53480e51e428c071',1,'consumibles.h']]],
  ['free_5fbullet_2',['free_bullet',['../bala_8h.html#a473767cc9e24eab122b61b52201342ec',1,'bala.h']]],
  ['free_5fburst_5fshot_3',['free_burst_shot',['../rafaga_8h.html#ab438410d7d17d4e27d00cf5486f467da',1,'rafaga.h']]],
  ['free_5fcam_4',['free_cam',['../camara_8h.html#a81b7be31934f35901f79902877cd5195',1,'camara.h']]],
  ['free_5fgame_5',['free_game',['../partida_8h.html#af168163284358f0be129ce9690211367',1,'partida.h']]],
  ['free_5fmap_6',['free_map',['../mapa_8h.html#a67839048f71d7c92b38a8e2e70daa56b',1,'mapa.h']]],
  ['free_5fplayer_7',['free_player',['../jugador_8h.html#ab7ebd1f84bb36b83419fed4bc7e74e04',1,'jugador.h']]]
];
