var searchData=
[
  ['end_5fgame_0',['end_game',['../partida_8h.html#a1b37582c1988a028a36439e5c499e796',1,'partida.h']]]
];
