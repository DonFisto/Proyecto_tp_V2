var searchData=
[
  ['pantalla_0',['Pantalla',['../struct_pantalla.html',1,'']]],
  ['partidarep_1',['PartidaRep',['../struct_partida_rep.html',1,'']]]
];
