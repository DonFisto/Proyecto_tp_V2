var annotated_dup =
[
    [ "BalaRep", "struct_bala_rep.html", null ],
    [ "CajaRep", "struct_caja_rep.html", null ],
    [ "EjercitoRep", "struct_ejercito_rep.html", null ],
    [ "EnemigoRep", "struct_enemigo_rep.html", null ],
    [ "ImagenRep", "struct_imagen_rep.html", null ],
    [ "JugadorRep", "struct_jugador_rep.html", null ],
    [ "Leaderboard", "struct_leaderboard.html", null ],
    [ "NodoBala", "struct_nodo_bala.html", null ],
    [ "Pantalla", "struct_pantalla.html", null ],
    [ "PartidaRep", "struct_partida_rep.html", null ]
];