var enemigos_8h =
[
    [ "Ejercito", "enemigos_8h.html#a10180dd7b9b6f8179b6be972176e7885", null ],
    [ "army_burst_shot_collision", "enemigos_8h.html#ae61339e3d64041995b7a94b123fd096d", null ],
    [ "create_army", "enemigos_8h.html#aa1897a656e1c037fddbfe14d51a92ab4", null ],
    [ "draw_army", "enemigos_8h.html#ad0f236714e5e44f66e5e4f1c88dff58c", null ],
    [ "free_army", "enemigos_8h.html#af841101131751dfb868b8c7d067507c2", null ],
    [ "get_army_ealive", "enemigos_8h.html#a121487f0b68d5e8366aac5416d276639", null ],
    [ "get_enemy_x", "enemigos_8h.html#a8f610f038318f4c3da25f1ed1a0d6083", null ],
    [ "get_enemy_y", "enemigos_8h.html#a14982a825a8aecae1861c27de31ad621", null ],
    [ "insert_enemy", "enemigos_8h.html#a933f4ecbd3c2312307e26030328ad29a", null ],
    [ "move_army", "enemigos_8h.html#a1f4387c6f3522a42c4230a1b0b55fe30", null ],
    [ "object_army_collision", "enemigos_8h.html#a57830f3968f93a7f6fd9add4c5a46729", null ],
    [ "set_ealive", "enemigos_8h.html#a2de475bf7ef11c273a716d82279c0051", null ]
];