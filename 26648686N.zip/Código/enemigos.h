#ifndef __enemigos_H__
#define __enemigos_H__
#include "camara.h"
#include "rafaga.h"
#include "mapa.h"

/**
   \file enemigos.h
   \brief  Fichero de cabecera para poder usar las funciones del m�dulo enemigos
*/

/**
    \brief TDA Ejercito
 */
typedef struct EjercitoRep * Ejercito;

/**
  \brief Devuelve el n�mero de enemigos vivos del ej�rcito
  \param e ej�rcito del que se devuelve la informaci�n.
  \return n�mero de enemigos vivos.
 */
int get_army_ealive(Ejercito e);

/**
  \brief Modifica el n�mero de enemigos vivos
  \param e ej�rcito en el que se modifican los parametros.
  \param n valor del parametro que se modifica.
 */
void set_ealive(Ejercito e, int n);

/**
  \brief Devuelve la coordenada x de un enemigo del ej�rcito
  \param e ej�rcito del que se devuelve la informaci�n.
  \param index posicion en el ej�rcito del enemigo del que se devuelve la informaci�n.
  \return coordenada x del enemigo correspondiente al �ndice.
 */
double get_enemy_x(Ejercito e, int index);

/**
  \brief Devuelve la coordenada y de un enemigo del ej�rcito
  \param e ej�rcito del que se devuelve la informaci�n.
  \param index posicion en el ej�rcito del enemigo del que se devuelve la informaci�n.
  \return coordenada y del enemigo correspondiente al �ndice.
 */
double get_enemy_y(Ejercito e, int index);


/**
  \brief Crea e inicializa un ej�rcito.
  \return ej�rcito inicializada.
 */
Ejercito create_army();

/**
  \brief Libera un ejercito.
  \param r r�faga a liberar.
 */
void free_army(Ejercito e);

/**
  \brief A�ade un enemigo a un ej�rcito con los parametros indicados.
  \param e ej�rcito al que se a�ade el enemigo.
  \param x coordenada x de la esquina superior izquierda del enemigo.
  \param y coordenada y de la esquina superior izquierda del enemigo.
  \param type tipo de enemigo.
 */
void insert_enemy(Ejercito e, double x, double y, int type);

/**
  \brief Mueve el ej�rcito.
  \param e ej�rcito a mover.
  \param jx coordenada x de la esquina superior izquierda del jugador.
  \param jy coordenada y de la esquina superior izquierda del jugador.
  \param jinv par�metro de invencibilidad del jugador.
  \param r rafaga disparada por los enemigos.
  \param m terreno en el que se desarrolla la partida.
 */
void move_army(Ejercito e, double jx, double jy, int jinv, Rafaga r, Mapa m);

/**
  \brief Dibuja un ej�rcito.
  \param e ej�rcito a dibujar.
  \param cam c�mara de la partida.
 */
void draw_army(Ejercito e, Camara cam);

/**
  \brief Detecta la colisi�n de un ej�rcito con un rect�ngulo.
  \param e ejercito a comprobar.
  \param x coordenada x de la esquina superior izquierda del rect�ngulo.
  \param y coordenada y de la esquina superior izquierda del rect�ngulo.
  \param w anchura del rect�ngulo.
  \param h altura del rect�ngulo.
  \return 0 si no hay colisi�n.
  \return 1 si hay colisi�n.
 */
int object_army_collision(Ejercito e, double x, double y, double w, double h);

/**
  \brief Detecta el n�mero de colisiones de un ej�rcito con una r�faga.
  \param e ej�rcito a comprobar.
  \param r rafaga a comprobar.
  \return n�mero de colisiones.
 */
int army_burst_shot_collision(Ejercito e, Rafaga r);

#endif
