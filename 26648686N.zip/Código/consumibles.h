#ifndef __consumibles_H__
#define __consumibles_H__
#include "camara.h"
#include "mapa.h"

/**
   \file consumibles.h
   \brief  Fichero de cabecera para poder usar las funciones del m�dulo consumibles
*/

/**
    \brief TDA Caja
 */
typedef struct CajaRep * Caja;

/**
  \brief Indica el tipo de consumible que es una caja
  \param c caja de la que se devuelve la informaci�n.
  \return 0-2 si la caja recarga la munici�n del jugador.
  \return 3 si la caja da un escudo al jugador.
  \return 4 si la caja incrementa las vidas del jugador.
  \return 5 si la caja habilita temporalmente el triple disparo para el jugador.

 */
int get_box_type(Caja c);

/**
  \brief Devuelve la coordenada x de una caja
  \param c caja de la que se devuelve la informaci�n.
  \return coordenada x de la caja.
 */
double get_box_x(Caja c);

/**
  \brief Devuelve la coordenada y de una caja
  \param c caja de la que se devuelve la informaci�n.
  \return coordenada y de la caja.
 */
double get_box_y(Caja c);


/**
  \brief Crea e inicializa un consumible.
  \return consumible con los valores inicializados.
 */
Caja create_box(Mapa m);

/**
  \brief Libera una caja.
  \param c caja a liberar.
 */
void free_box(Caja c);

/**
  \brief Detecta la colisi�n de una caja con un rect�ngulo.
  \param c caja a comprobar.
  \param x coordenada x de la esquina superior izquierda del rect�ngulo.
  \param y coordenada y de la esquina superior izquierda del rect�ngulo.
  \param w anchura del rect�ngulo.
  \param h altura del rect�ngulo.
  \return 0 si no hay colisi�n.
  \return 1 si hay colisi�n.
 */
int box_collision(Caja c, double x, double y, double w, double h);

/**
  \brief Cambia de posici�n una caja.
  \param c caja a mover.
  \param m terreno en el que se desarrolla la partida.
 */
void move_box(Caja c, Mapa m);

/**
  \brief Dibuja una caja.
  \param c caja a dibujar.
 */
void draw_box(Caja c, Camara cam);

#endif
