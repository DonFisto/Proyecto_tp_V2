#ifndef __jugador_H__
#define __jugador_H__
#include "camara.h"
#include "rafaga.h"
#include "mapa.h"

/**
   \file jugador.h
   \brief  Fichero de cabecera para poder usar las funciones del m�dulo jugador
*/

/**
    \brief TDA Jugador
 */
typedef struct JugadorRep * Jugador;

/**
  \brief Devuelve la coordenada x de la posici�n de un jugador.
  \param j jugador del que se devuelve la informaci�n.
  \return valor de la coordenada x del jugador.
 */
double get_player_pos_x(Jugador j);

/**
  \brief Devuelve la coordenada y de la posici�n de un jugador.
  \param j jugador del que se devuelve la informaci�n.
  \return valor de la coordenada y del jugador.
 */
double get_player_pos_y(Jugador j);

/**
  \brief Devuelve la anchura de un jugador.
  \param j jugador del que se devuelve la informaci�n.
  \return valor de la anchura del jugador.
 */
double get_player_width(Jugador j);

/**
  \brief Devuelve la altura de un jugador.
  \param j jugador del que se devuelve la informaci�n.
  \return valor de la altura del jugador.
 */
double get_player_height(Jugador j);

/**
  \brief Devuelve la coordenada x de la direcci�n a la que apunta un jugador.
  \param j jugador del que se devuelve la informaci�n.
  \return valor de la coordenada x de la direcci�n a la que apunta el jugador.
 */
double get_player_aimx(Jugador j);

/**
  \brief Devuelve la coordenada y de la direcci�n a la que apunta un jugador.
  \param j jugador del que se devuelve la informaci�n.
  \return valor de la coordenada y de la direcci�n a la que apunta el jugador.
 */
double get_player_aimy(Jugador j);

/**
  \brief Devuelve la munici�n restante de un jugador.
  \param j jugador del que se devuelve la informaci�n.
  \return valor de la munici�n del jugador.
 */
int get_player_energy(Jugador j);

/**
  \brief Devuelve el n�mero de vidas de un jugador.
  \param j jugador del que se devuelve la informaci�n.
  \return n�mero de vidas del jugador.
 */
int get_player_lives(Jugador j);

/**
  \brief Devuelve el tiempo restante de invencibilidad de un jugador.
  \param j jugador del que se devuelve la informaci�n.
  \return tiempo restante de invencibilidad del jugador.
 */
int get_player_inv(Jugador j);

/**
  \brief Devuelve el tiempo restante de enfriamiento al disparar de un jugador.
  \param j jugador del que se devuelve la informaci�n.
  \return tiempo restante de enfriamiento al disparar del jugador.
 */
int get_player_cooldown(Jugador j);

/**
  \brief Inflinge da�o a un jugador.
  \param j jugador al que se inflinge da�o.
 */
void dmg(Jugador j);

/**
  \brief Modifica el tiempo de invencibilidad del jugador.
  \param j jugador al que se modifican los par�metros.
  \param t tiempo de invencibilidad.
 */
void set_inv(Jugador j, int t);

/**
  \brief Modifica la munici�n del jugador.
  \param j jugador al que se modifican los par�metros.
  \param e munici�n.
 */
void set_energy(Jugador j, int e);

/**
  \brief Activa el disparo triple del jugador.
  \param j jugador al que se modifican los par�metros.
 */
void set_triple_shot(Jugador j);


/**
  \brief Modifica el n�mero de vidas del jugador.
  \param j jugador al que se modifican los par�metros.
  \param l n�mero de vidas.
 */
void set_lives(Jugador j, int l);

/**
  \brief Modifica el color del jugador de forma gradual.
  \param j jugador al que se modifican los par�metros.
 */
void color_change(Jugador j);

/**
  \brief Crea e inicializa un jugador.
  \return jugador con los valores inicializados.
 */
Jugador create_player();

/**
  \brief Libera un jugador.
  \param jugador a liberar.
 */
void free_player(Jugador j);

/**
  \brief Dibuja un jugador.
  \param jugador a dibujar.
  \param cam c�mara de la partida.
 */
void draw_player(Jugador j, Camara cam);

/**
  \brief Mueve un jugador.
  \param j jugador a mover.
  \param r rafaga disparada por los jugadores.
  \param m terreno en el que se desarrolla la partida.
 */
void move_player(Jugador j, Rafaga r, Mapa m);

#endif
