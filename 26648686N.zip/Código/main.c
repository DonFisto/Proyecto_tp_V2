#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "Pantalla.h"
#include "jugador.h"
#include "constantes.h"
#include "rafaga.h"
#include "enemigos.h"
#include "consumibles.h"
#include "partida.h"
#include "mapa.h"
#include "camara.h"

int main( int argc, char *argv[] )
{

    crea_pantalla( "Ejemplo 2", CAMERA_W, CAMERA_H);
    printf("* * * * * INICIO JUEGO * * * * *\n\n\n\n\n");
    Mapa m = create_map();
    read_map(m);
    Partida p = start_game();
    Jugador j = create_player();
    Ejercito e = create_army();
    Rafaga rj = create_burst_shot();
    Rafaga re = create_burst_shot();
    Caja c = create_box(m);
    Camara cam = create_camera(0, 0);
    end_game(p);

    while ( pantalla_activa())
    {
        if(get_game_active(p))
        {
            if(!get_game_pause(p))
            {
            rellena_fondo( 255,255,255, 255 );
            game(p, j, e, rj, re, c, m, cam);
            draw_game(p, j, e, rj, re, c, m, cam);
            }
            else
            {
                draw_game(p, j, e, rj, re, c, m, cam);
                int outcome = pause_menu(p);
                   if(outcome == 1)
                   {
                        unpause(p);
                   }
                   if(outcome == 2)
                   {
                       update_records(p);
                       end_game(p);
                   }
            }
            actualiza_pantalla();
            espera(10);


        }
        else
        {

            rellena_fondo( 100,100,100, 255 );
            draw_minimap(m, 0, 0, 1);
            int result = menu(p);
            if(result == 1)
            {
                p = start_game();
                j = create_player();
                e = create_army();
                rj = create_burst_shot();
                re = create_burst_shot();
                c = create_box(m);
            }
            else if(result == 2)
            {
                j = create_player();
                ayuda(p, j, e, rj, cam);

            }
            else if(result == 3)
            {
                save_map(m);
                free_map(m);
                free_cam(cam);
                free_player(j);
                free_army(e);
                free_burst_shot(rj);
                free_burst_shot(re);
                free_box(c);
                libera_pantalla();
                return 0;
            }
            else if(result == 4)
            {
                reset_map(m);
                generate_map(m, 500);
            }
            actualiza_pantalla();
            espera(10);
        }
    }
    libera_pantalla ();
    return 0;
}
