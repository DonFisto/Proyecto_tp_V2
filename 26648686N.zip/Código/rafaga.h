#ifndef __rafaga_H__
#define __rafaga_H__
#include "bala.h"
#include "camara.h"
#include "mapa.h"
/**
   \file rafaga.h
   \brief  Fichero de cabecera para poder usar las funciones del m�dulo rafaga
*/

/**
    \brief TDA Rafaga
 */
typedef struct NodoBala * Rafaga;

/**
  \brief Crea e inicializa una r�faga.
  \return r�faga inicializada.
 */
Rafaga create_burst_shot();

/**
  \brief Libera una r�faga.
  \param r r�faga a liberar.
 */
void free_burst_shot(Rafaga r);

/**
  \brief A�ade una bala a una r�faga.
  \param r r�faga a la que se a�ade la bala.
  \param b bala a a�adir.
 */
void insert_burst(Rafaga r, Bala b);

/**
  \brief Mueve una r�faga.
  \param r r�faga a mover.
  \param m terreno sobre el que se mueve la r�faga.
 */
void move_burst_shot(Rafaga r, Mapa m);

/**
  \brief Dibuja una r�faga.
  \param r r�faga a dibujar.
  \param cam c�mara de la partida.
 */
void draw_burst_shot(Rafaga r, Camara cam);

/**
  \brief Devuelve la longitud de una r�faga.
  \param r r�faga de la que se devuelve la informaci�n.
  \return n�mero de elementos de la r�faga.
 */
int burst_shot_lenght(Rafaga r);

/**
  \brief Detecta la colisi�n de una r�faga con un rect�ngulo.
  \param r r�faga a comprobar.
  \param x coordenada x de la esquina superior izquierda del rect�ngulo.
  \param y coordenada y de la esquina superior izquierda del rect�ngulo.
  \param w anchura del rect�ngulo.
  \param h altura del rect�ngulo.
  \return 0 si no hay colisi�n.
  \return 1 si hay colisi�n.
 */
int burst_shot_collision(Rafaga r, double x, double y, double w, double h);

#endif
