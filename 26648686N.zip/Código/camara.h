#ifndef __camara_H__
#define __camara_H__

/**
   \file camara.h
   \brief  Fichero de cabecera para poder usar las funciones del m�dulo c�mara
*/

/**
    \brief TDA Mapa
 */
typedef struct CamaraRep * Camara;

/**
  \brief Devuelve la coordenada x de la c�mara.
  \param cam c�mara de la que se devuelve la informaci�n.
  \return valor de la coordenada x de la c�mara.
 */
double get_cam_x(Camara cam);

/**
  \brief Devuelve la coordenada y de la c�mara.
  \param cam c�mara de la que se devuelve la informaci�n.
  \return valor de la coordenada y de la c�mara.
 */
double get_cam_y(Camara cam);

/**
  \brief Crea e inicializa una c�mara con los valores especificados.
  \param x coordenada x de la c�mara.
  \param y coordenada y de la c�mara.
  \return c�mara con los valores inicializados.
 */
Camara create_camera(double x, double y);

/**
  \brief Libera una c�mara.
  \param cam c�mara liberada.
 */
void free_cam(Camara cam);

/**
  \brief Mueve la c�mara en relaci�n a un punto.
  \param x coordenada x del punto.
  \param y coordenada y del punto.
 */
void camera_follow(Camara cam, double x, double y);

#endif
