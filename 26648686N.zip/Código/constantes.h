#ifndef __constantes_H__
#define __constantes_H__

/**
   \file constantes.h
   \brief  El modulo constantes recoge los datos constantes que se utilizan repetidamente en los distintos componentes del proyecto.

   Este modulo consta de los siguientes elementos:<br/>
 <br/> W: define el ancho de la pantalla creada
 <br/> H: define el alto de la pantalla creada
 <br/> LB_SIZE: define el numero de puntuaciones que se almacenan en la tabla de records
 <br/> PI: almacena el valor de la constante matem�tica, usada para operaciones con �ngulos en este proyecto
 <br/> T_MAX_EJERCITO: define el numero m�ximo de enemigos que puede haber simultaneamente
 <br/> TROUND: define el tiempo que dura cada ronda
 <br/> BLOCK_SIZE: define el tiempo que dura cada ronda
 <br/> CAMERA_W: define el ancho de la c�mara
 <br/> CAMERA_H: define el alto de la c�mara
 <br/> CAMERA_TRACKING_SPEED: define la velocidad con la que la c�mara persigue a un punto
*/

#define W 6000
#define H 3000
#define LB_SIZE 10
#define PI 3.14159265358979323846
#define T_MAX_EJERCITO 30
#define TROUND 500
#define BLOCK_SIZE 30
#define CAMERA_W 1300
#define CAMERA_H 700
#define CAMERA_TRACKING_SPEED 3

#endif
